﻿This folder is used by some of our demo apps in conjunction with the sync/async/batch processing features - see http://help.qlik.com/en-US/connectors/csh/client/Web_Connectors_help|synchronous_requests

The QlikView / Qlik Sense store command can be used to write CSV files here which are then read and processed by Qlik Web Connectors.

You are not required to use this folder but should choose a location where QlikView / Qlik Sense has permission to write to and Qlik Web Connectors has permission to read from.